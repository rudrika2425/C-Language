/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int radius,diameter,circumference,area;
    printf("enter radius of circle:");
    scanf("%d",&radius);
    diameter=2*radius;
    circumference=2*3.14*radius;
    area=3.14*radius*radius;
    printf("diameter of circle is:%d",diameter);
    printf("\ncircumference of circle is:%d",circumference );
    printf("\narea of circle is:%d",area);
    return 0;
}

    

