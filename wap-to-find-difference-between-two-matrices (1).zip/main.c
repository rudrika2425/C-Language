/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int a[100][100],b[100][100],n,m,i,j,c,d;
    printf("enter rows of matrix ");
    scanf("%d",&n);
    printf("enter columns of matrix ");
    scanf("%d",&m);
    ////////////////////////////////////////////////////
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
           printf("%d    ",a[i][j]);
        }
        printf("\n");
    }
    //////////////////////////////////////////////////////////////
    printf("enter rows of matrix ");
    scanf("%d",&c);
    printf("enter columns of matrix ");
    scanf("%d",&d);
    
     for(i=0;i<c;i++)
    {
        for(j=0;j<d;j++)
        {
            scanf("%d",&b[i][j]);
        }
    }
    for(i=0;i<c;i++)
    {
        for(j=0;j<d;j++)
        {
           printf("%d    ",b[i][j]);
        }
        printf("\n");
         printf("\n");
          printf("\n");
    }
    //////////////////////////////////////////////////////////////////
    printf(" difference of two matrices are as follow:");
    printf("\n");
    int  difference[n][m];
    if(n==c && m==d)
    {
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                difference[i][j]= a[i][j]-b[i][j];
            }
        }
         for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
               printf("%d   ",difference[i][j]);
            }
                printf("\n"); 
        }
    }
   

    return 0;
}
