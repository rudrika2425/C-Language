/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main ()
{
  int n, a[n], i, m, element, position;
  printf ("Enter size of array  ");
  scanf ("%d", &n);
  printf ("Enter number of elemengs of array  ");
  scanf ("%d", &m);
  for (i = 0; i < m; i++)
    {
      scanf ("%d", &a[i]);
    }
  printf ("Enter element and position which is to be deleted  ");
  scanf ("%d%d", &element, &position);
  for (i = position-1; i < m - 1; i++)
    {
      a[i] = a[i + 1];
    }
  for(i = 0; i < m-1; i++)
    {
      printf("%d", a[i]);
    }

  return 0;
}
