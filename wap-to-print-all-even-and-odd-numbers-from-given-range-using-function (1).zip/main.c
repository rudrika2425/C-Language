/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int even_odd(int n)
{
    int i;
scanf("%d",&n);
printf("range of even numbers is as follow:\n");
for (i=0;i<n;i++)
{
    if (i%2==0)
    printf("%d, ",i);
}
printf("\n");
printf("range of odd numbers is as follow:\n");
for (i=0;i<n;i++)
{
    if (i%2!=0)
    printf("%d, ",i);
}
printf("\n");
}
int main()
{
    int n;
even_odd(n);
return 0;
}

