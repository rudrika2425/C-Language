/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  int a,b ,sum,substract,divide,multiply;
  printf("enter value for a:");
  scanf(" %d",&a);
  printf("\nenter value for b:");
  scanf(" %d",&b);
  sum=a+b;
  substract=a-b;
  divide=a/b;
  multiply=a*b;
  printf("sum is: %d \n",sum);
  printf("substract is: %d \n",substract);
  printf("divide is: %d \n",divide);
  printf("multiply is: %d \n",multiply);
    return 0;
}
