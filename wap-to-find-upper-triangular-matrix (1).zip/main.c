/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int n,m,i,j,x,y;
    printf("enter rows of matrix ");
    scanf("%d",&n);
    printf("enter columns of matrix ");
    scanf("%d",&m);
    int a[n][m],b[n][m];
    
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
           printf("%d    ",a[i][j]);
        }
        printf("\n");
    }
    
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
           if(i<=j && a[i][j]==0)
           x++;   //// always take complement first priority in if
           else 
           y++;
         }
    }
        if(x!=0)
        printf(" not upper triangular matrix");
        else
        printf("  upper triangualr matrix");


    return 0;
}


