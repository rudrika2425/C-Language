/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>
int main()
{
   int principle_amount,time_gap,simple_interest,rate;
   printf("enter value for principle amount:");
   scanf("%d",&principle_amount);
    printf("enter value for time_gap:");
      scanf("%d",&time_gap);
      printf("enter value for rate:");
      scanf("%d",&rate);
      simple_interest=(principle_amount*rate*time_gap)/100;
      printf("enter value for simple_interest:%d",simple_interest);



    return 0;
}

