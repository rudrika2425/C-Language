/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>


int hcf_lcm()
{
 int x, y, hcf, lcm;

  
  hcf=gcd(x, y);
  lcm=(x*y)/hcf;

  printf("Greatest common divisor of %d and %d = %d\n", x, y, hcf);
  printf("Least common multiple of %d and %d = %d\n", x, y, lcm);

  return 0;
}

int gcd(int x, int y)
{
  if (x == 0) 
  {
    return y;
  }

  while (y != 0)
  {
    if (x > y)
      x = x - y;
    else
      y = y - x;
  }

  return x;
}
int main