/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int diameter(int r)
{
return 2*r;
}
int area(int r)
{
return 3.14*r*r;
}
int circumference(int r)
{
return 2*3.14*r;
}
int main()
{
    int r,a,b,c;
    printf("enter radius");
    scanf("%d",&r);
    a=diameter(r);
    b=area(r);
    c=circumference(r);
    printf("%d\n%d\n%d",a,b,c);

}

