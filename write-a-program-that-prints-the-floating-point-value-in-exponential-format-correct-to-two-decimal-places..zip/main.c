/******************************************************************************

Welcome to GDB Online
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float a;
    printf("enter a float number:");
    scanf("%f",&a);
    printf("The float number upto correct two decimal places is%0.2f",a);  
    printf("The exponential number upto correct two decimal places is%0.2e",a);
    return 0;
}
