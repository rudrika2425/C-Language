/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,d,sum=0,b,c,a;
    printf("enter number");
    scanf("%d",&n);
    d=log10(n)+1;
    a=n;
    while(a>0)
    {
        b=a%10;
        c=pow(b,d);
        sum=sum+c;
        a=a/10;
    }
    if(sum == n)
    {
        printf("The number is armstrong");
        
    }
    else
    {
        printf("Not an armstrong");
    }
    return 0;
}
