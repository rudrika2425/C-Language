/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>


    int main()
{
    char ch;
    scanf("%c",&ch);
    
    switch(ch)
{
      case 'a':
      printf("vowel");
      break;
      
      case 'e':
      printf("vowel");
      break;

      case 'i':
      printf("vowel");
      break;
    
      case 'o':
      printf("vowel");
      break;
      
      case 'A':
      printf("vowel");
      break;
      
      case 'E':
      printf("vowel");
      break;
      
      case 'I':
      printf("vowel");
      break;
      
      case 'O':
      printf("vowel");
      break;
      
      case 'U':
      printf("vowel");
      break;
      
      
      
    default:
      printf("CONSTANT");
}


    return 0;
}
