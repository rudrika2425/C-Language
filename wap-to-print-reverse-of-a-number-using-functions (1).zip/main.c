/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int reverse(int n)
{
int sum=0,r,a;
scanf("%d",&n);
a=n;
while(a!=0)
{
    r=a%10;
    sum=(sum*10)+r;
    a=a/10;
}
printf("%d",sum);
}
int main()
{
    int n;
    reverse(n);

    return 0;
}
