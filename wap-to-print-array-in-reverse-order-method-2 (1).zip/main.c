/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int i,a[10]={1,2,3,4,5,6,7,8,9,10};
   printf("origional array\n");
   for(i=0;i<10;i++)
   {
       printf("%d ",a[i]);
   }
printf("\n");
printf("In reverse order\n");
   for(i=9;i>=0;i--)
   {
       printf("%d ",a[i]);
   }
return 0;
}