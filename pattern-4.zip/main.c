/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>


    int main()
{ 
    int i,count;
    char input;
    count=1;
    printf("Enter an uppercase character you want to print in the last row: ");
    scanf("%c", &input);
    for (char k=input;k<='Z';k++)
 { 
     for (int j=1;j<=count;j++)
 {
    printf("%c ",k);
 }
 ++count;
 printf("\n");
 }

    return 0;
}


    


   
