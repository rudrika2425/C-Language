/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int max(int a,int b)
{
if (a>b)
printf("max:%d\n",a);
else
printf("max:%d\n",b);
}
int min(int a,int b)
{
if (a>b)
printf("min:%d\n",b);
else
printf("min:%d\n",a);
}


int main()
{
    int a,b;
    printf("enter value for a and b\n");
    scanf("%d",&a);
    scanf("%d",&b);
    max(a,b);
    min(a,b);
}