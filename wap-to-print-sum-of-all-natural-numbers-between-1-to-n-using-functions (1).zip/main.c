/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int addition(int n)
{
    int c,i,sum=0;
    for(i=1;i<n;i++)
    {
        sum=sum+i;
    }
    printf("%d",sum);
}
int main()
{
   int d,n;
   scanf("%d",&n);
   d=addition(n);

    return 0;
}

