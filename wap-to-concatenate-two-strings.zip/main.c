/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int main()
{
	int i,k,j;
char a[100];
char b[100];
char c[200];
scanf("%s",a);
scanf("%s",b);
for(i=0;a[i];i++)
{
	c[i]=a[i];
}
for(k=i,j=0;b[j];j++,k++)
{
	c[k]=b[j];
}
c[k]=0;
printf("%s",c);
return 0;
}