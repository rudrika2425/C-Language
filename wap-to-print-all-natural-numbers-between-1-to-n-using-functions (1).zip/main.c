/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int natural(int n)
{
  
   for( int i=1;i<n;i++)
   {
   printf("%d",i);
   }
}
   
int main()
{
    int n,number;
    scanf("%d",&n);
    number=natural(n);
   return 0;
}

