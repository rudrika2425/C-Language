/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int x=8;
printf("x=%d\t",x);
printf ("x=%d\t",++x); /*prefix increment*/
printf ("x=%d\t" ,x) ;
printf ("x=%d\t", - --x); /*prefix decrement*/
printf ("x=%d\n",x);







    return 0;
}
