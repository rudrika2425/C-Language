/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main()
{
int i,j,temp;
int arr[lO]= {1,2,3,4,5,6,7,8,9,10};
for(i=O;j=9;i<j;i++;j--)
{
temp=arr[i];
arr [i] = arr [j] ;
arr[j]=temp;
}
printf ("After reversing the array is) :
for(i=O;i<10;i++)
{
printf("%d ",arr[i]);
printf("\n");
}
return 0;
}
