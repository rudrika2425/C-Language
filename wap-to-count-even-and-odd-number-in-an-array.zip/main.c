/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,i,even=0,odd=0;
    printf("Enter the number of terms for array:\n");
    scanf("%d",&n);
    printf("Enter the terms for array:\n");
     int a[n];
    for(i=1;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=1;i<n;i++)
    {
        printf("%d\t",a[i]);
    }
     for(i=1;i<n;i++)
     {
         if(a[i]%2==0)
         {
           even++;
         }
         else
         {
             odd++;
         }
         
    }
    printf("\ntotal number of even terms in array are:%d  \n",even);
    printf("total number of odd terms in array are:%d  \n",odd);
     
    return 0;
   }
