/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int a,b,c,area,s;
    printf("enter a of triangle:");
    scanf("%d",&a);
    printf("enter b of triangle:");
    scanf("%d",&b);
    printf("enter side_c of triangle:");
    scanf("%d",&c);
    s=(a + b + c)/2;
    area=sqrt(s*(s-a)*(s-b)*(s-c));
    printf("area is triangle is:%d",area);
    
    return 0;
}
