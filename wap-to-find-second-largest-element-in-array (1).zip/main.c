/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a[100], n, i, j, swap;

  printf("Enter number of elements\n");
  scanf("%d", &n);
  printf("Enter %d elements\n", n);
  for (i=0; i<n; i++)
    scanf("%d", &a[i]);

  for (i= 0;i<n-1;i++)
  {
    for (j= 0;j<n-i-1;j++)
    {
      if (a[j]>a[j+1]) /* For decreasing order use '<' instead of '>' */
      {
        swap=a[j];
        a[j]= a[j+1];
        a[j+1]=swap;
      }
    }
  }

  printf("Sorted list in ascending order:\n");

  for (i= 0;i<n;i++)
  {
     printf("%d ",a[i]);
  }
     printf("\nsecond largest number: %d",a[n-2]);
    return 0;
}

