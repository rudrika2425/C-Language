/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char ch;
    scanf("%c",&ch);
    
    switch(ch)
{
      case 1:
      printf("31");
      break;
      
      case 2:
      printf("28");
      break;
      
      case 3:
      printf("31");
      break;
      
      case 4:
      printf("30");
      break;
      
      case 5:
      printf("31");
      break;
      
      case 6:
      printf("30");
      break;
      
      case 7:
      printf("31");
      break;
      
      case 8:
      printf("31");
      break;
      
      case 9:
      printf("30");
      break;
      
       case 10:
      printf("31");
      break;
      
       case 11:
      printf("30");
      break;
      
       case 12:
      printf("31");
      break;
    default:
      printf("CONSTANT");
}


    return 0;
}

