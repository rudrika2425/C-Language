/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int days,years,weeks,days_left;
    printf("enter no. of days:");
    scanf("%d",&days);
    years=days/365;
    weeks=days/7;
    days_left=days-(years*365);
    printf("number of years:%d",years);
    printf("\nnumber of weeks:%d",weeks);
    printf("\nnumber of days left:%d",days_left);
    return 0;
    
}
