/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int base,height,area;
    printf("enter base of triangle:");
    scanf("%d",&base);
    printf("enter height of triangle:");
    scanf("%d",&height);
    area = base*height*0.5;
    printf("area of traingle is:%d",area);

    return 0;
}
