/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
 #include <stdio.h>

int main()
{
   int i,a[10],n,element,flag=0,k;
   printf("Enter the number of elements in array:");
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
    scanf("%d",&a[i]);
   }
   printf("Enter the elements to be searched in array:");
   scanf("%d",&element);
   for(i=0;i<n;i++)
   {
    if(a[i]==element)
    {
        flag=1;
        k=i+1;
        break;
    }
    }
   if(flag==1)
   {
       printf("%d number is found ",k);
   }
   else
   {
       printf("number is not found");
   }

  return 0;
}