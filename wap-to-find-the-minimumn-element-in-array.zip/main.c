/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

 int main()
{
     int a[10],min;
   printf("Enter the elements of array:");
   scanf("%d",(a));
  
   min=a[0];
   for (int i=1;i<10;i++)
   {
       scanf("%d",(a+i));
       if((i>0)&&(min>a[i]))
       min=a[i];
   }
   printf("The minimum element is:%d",min);


    return 0;
}
