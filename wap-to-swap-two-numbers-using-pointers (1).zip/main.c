/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a,b,*p,*q,*r,sum;
   scanf("%d",&a);
    scanf("%d",&b);
   p=&a;
   q=&b;
   printf("a=%d\n", *p);   
   printf("b=%d\n", *p);
   
   *r=*p;
   *p=*q;
   *q=*r;
   printf("numbers after swaping");  
   printf("\na=%d", *p);   
   printf("\nb=%d\n", *q);
    
   
    return 0;
}
