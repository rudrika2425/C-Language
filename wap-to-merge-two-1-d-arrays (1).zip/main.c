/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,m,i,J;
    printf("enter size of array a : ");
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
     int b[n];
     printf("enter size of array b : ");
    scanf("%d",&m);
    
    for(i=0;i<m;i++)
    {
        scanf("%d",&b[i]);
    }
    printf("matrix a is:\n");
    
    for(i=0;i<n;i++)
    {
        printf("%d  ",a[i]);
    }
    printf("\n");
     printf("matrix b is:\n");
    for(i=0;i<m;i++)
    {
        printf("%d  ",b[i]);
    }
    printf("\n");
    if(n==m)
    {
    printf("on merging both the array we will get");
    printf("\n");
    printf("\n");
    int c[n];
    
    for(i=0;i<n;i++)
    {
        c[i]=a[i]+b[i];
    }
    for(i=0;i<n;i++)
    {
        printf("%d  ",c[i]);
    }
    }
    return 0;
}
