/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,i;
    printf("enter len : ");
    scanf("%d",&n);
    printf("enter array : ");
    int a[n];
    for(int i=0;i<n;i++)
    {
    scanf("%d",&a[i]);
    }
    int l=n-1;
    int temp=a[l];
    while(l>0)
    {
    a[l]=a[l-1];
    l--;
    }
    a[0]=temp;
    printf("array after right shift\n");
    for(int i=0;i<n;i++)
    {
        printf("%d",a[i]);
    }

    return 0;
}
