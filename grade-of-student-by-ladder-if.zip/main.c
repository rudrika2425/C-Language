/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int science,maths,english,hindi,sst,average,percentage;
     float total;
     
    printf("enter marks for science:");
    scanf("%d",&science);
    (science>100)?printf("marks invalid\n"):printf("\0");
    printf("enter marks for maths:");
    scanf("%d",&maths);
    (maths>100)?printf("marks invalid\n"):printf("\0");
    printf("enter marks for english:");
    scanf("%d",&english);
    (english>100)?printf("marks invalid\n"):printf("\0");
    printf("enter marks for hindi:");
    scanf("%d",&hindi);
    (hindi>100)?printf("marks invalid\n"):printf("\0");
    printf("enter marks for sst:");
    scanf("%d",&sst);
     (sst>100)?printf("marks invalid\n"):printf("\0");
    total=(science+maths+english+hindi+sst);
    average=((science+maths+english+hindi+sst)/5);
    percentage=((total/500)*100);
    printf("total:%f",total);
    printf("\naverage:%d",average);
    printf("\npercentage:%d",percentage);
    
        if(percentage>=90 && percentage<=100)
       {
           printf("\nstudent qualified with grade A");
       }
        
        else if(percentage>=80 && percentage<=90)
        {
            printf("\nstudent qualified with grade B");
        }
        
        else if(percentage>=80 && percentage<=90)
        {
            printf("\nstudent qualified with grade C");
        }
        
        else if (percentage>=70 && percentage<=80)
       {
           printf("\nstudent qualified with grade D");
       }
        
        else if (percentage>=60 && percentage<=70)
        {
            printf("\nstudent qualified with grade E");
        }
        
        else
        {
            
        printf("\nstudent failed !!!");
        }
    
    return 0;
}


