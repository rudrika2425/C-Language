/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int reverse(int n)
{
    int a,r,i,s=0;
    a=n;
    while(a!=0)
    {
    r=a%10;
    s=(s*10)+r;
    a=a/10;
    }
    
    printf("%d",s);
}
int main()
{
   int d,n;
   scanf("%d",&n);
   d=reverse(n);

    return 0;
}