/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     float a,b,product;
    printf("Enter value for a:");
    scanf("%f",&a);
    printf("Enter value for b:");
    scanf("%f",&b);
    product=a*b;
    printf("product=%f",product);
    return 0;
    return 0;
}
