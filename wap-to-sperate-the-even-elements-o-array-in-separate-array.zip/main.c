/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int n,i,sum=0,count=0,x=0;
    printf("Enter size of array:");
    scanf("%d",&n);
    int a[n];
    printf("Enter elements of array:");
    
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    
    
    for(i=0;i<n;i++)
    {
        printf("%d ",a[i]);
    }
    printf("\n");
    int b[x];
    
    for(i=0;i<n;i++)
    {
       if(a[i]%2==0)
      { 
      b[x]=a[i];
       x++;
          
      }
    }  
    for(i=0;i<x;i++)
    {
    printf("%d",b[i]);
    
    }

    return 0;
}
