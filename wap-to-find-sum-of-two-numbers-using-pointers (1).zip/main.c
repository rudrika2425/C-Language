/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a,b,*p,*q,sum;
   a=5;
   b=7;
   p=&a;
   q=&b;
   sum=*p+*q;
   printf("value is: %d\n", *p);   
   printf("address is: %p\n", p);   
   printf("value is: %d\n", *q);   
   printf("address is: %p\n", q); //%p address where the sum is stored 
    printf("sum is: %d\n", sum);  //%dvalue of sum
   
    return 0;
}