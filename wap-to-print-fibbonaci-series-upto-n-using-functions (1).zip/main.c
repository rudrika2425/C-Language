/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int Fibonacci(int n)
{
    int i;
    int a = 0, b = 1;
    int c =a + b;
    printf("Enter the number of terms: ");
    scanf("%d", &n);
    printf("Fibonacci Series: %d, %d, ", a, b);
    for (i = 3; i <= n; ++i)
    {
    printf("%d, ",c);
    a=b;
    b=c;
    c=a+b;
    }
    
}


int main()
{
    int n;
    Fibonacci(n);

    return 0;
}
