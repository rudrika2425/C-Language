/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int a[100][100],n,m,i,j,sum=0,x,y;
    printf("enter rows of matrix ");
    scanf("%d",&n);
    printf("enter columns of matrix ");
    scanf("%d",&m);
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
           printf("%d    ",a[i][j]);
        }
        printf("\n");
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            if (a[i][j] != a[j][i])
            x = 1;
         else if (a[i][j] == a[j][i])
            y = 1;
      }
   }
   if (y== 1)
     printf( "The matrix is symmetric");

   else if (x == 1)
   printf("The matrix is not symmetric");
    return 0;
}
