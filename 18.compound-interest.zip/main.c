/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int principle_amount,time_gap,compound_interest,n,rate;
   printf("enter value for principle amount:");
   scanf("%d",&principle_amount);
    printf("enter value for time_gap:");
      scanf("%d",&time_gap);
       printf("enter value for n:");
      scanf("%d",&n);
      printf("enter value for rate:");
      scanf("%d",&rate);
      
      compound_interest=principle_amount*(pow((1+(rate/n)),(n*time_gap)));
      printf("enter value for compound_interest:%d",compound_interest);

    return 0;
}
