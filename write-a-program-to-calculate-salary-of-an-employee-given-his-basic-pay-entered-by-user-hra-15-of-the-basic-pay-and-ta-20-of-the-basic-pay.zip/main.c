/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{   float basic_pay,TA,HRA,salary;
    printf("Enter basic pay of employee:");
    scanf("%f",&basic_pay);
    HRA=((20.0/100)*basic_pay);
    TA= (15.0/100)*basic_pay;
    salary=HRA+TA+basic_pay;
    printf("salary of the employee is:%f",salary);

    return 0;
}
