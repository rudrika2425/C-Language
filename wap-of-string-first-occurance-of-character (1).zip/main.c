/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>

int main()
{
    char a[20];
    char n;
    fgets(a,20,stdin);
    printf("chracter to be searched:");
    scanf("%c",&n);
    for(int i=0;a[i];i++)
    {
     if(a[i]==n){
        printf("element found at%d",i+1);
        break;
        }

     }
    
    return 0;
}