/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

 int cube(int a)
{
return a*a*a;
}
int main()
{
    int a,c;
    printf("enter the number");
    scanf("%d",&a);
    c=cube(a);
    printf("%d",c);

}

