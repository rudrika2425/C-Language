/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>   ////   123221

int main()
{
    int a,n,r,sum=0;
    scanf("%d",&n);
    a=n;
    while(n!=0)
    {
        r=n%10;
        sum=(sum*10)+r;
        n=n/10;
    }
    
    if (sum==a)
    printf("pallidrome");
    else
    printf("not a paliidrome");

    return 0;
}
